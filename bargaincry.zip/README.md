# restro
A Pos Application for restaurant
