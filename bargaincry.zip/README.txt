Remember to setup the database using the provided HOGO.sql script. Your database should be named "HOGO". 

IMPORTANT!!! Also, ensure that the base path and image path in application/config/config.php points to the location where you have deployed the application. 

You would need the following details to demo the application.

Table Setup
===========
EmployeeID: 000000
Table Number: 1 (could be any number)
Device Number: 1 (could be any number)

Waiter
======
EmployeeID: 000001

Kitchen
=======
EmployeeID: 000000

Manager
=======
EmployeeID: 000003

Of course, you can create new users in the manager section.